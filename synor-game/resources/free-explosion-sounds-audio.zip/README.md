# Free Explosion Sounds - 8 Game Sound Effects, Free

8 sound effects, free for commercial and non-commercial work with no
attribution required. These are the shipped files at the shipped levels, copied
out of a paid pack rather than made separately - the product, just less of it.

| File | Length |
| --- | --- |
| desert-open-air-blast-2.wav | 2.7s |
| bounding-mine-pop.wav | 1.3s |
| blast-heard-through-wall-2.wav | 2.1s |
| glass-bottle-impact-break-3.wav | 0.9s |
| thick-tree-branch-crack-1.wav | 0.8s |
| metal-drum-dented-impact-2.wav | 1.1s |
| signal-flare-ignition-1.wav | 1.0s |
| remote-detonator-click-2.wav | 0.8s |

Total runtime 11s. Uncompressed WAV, 44.1 kHz 16-bit stereo,
1.8 MB. Every file measures below -0.3 dB true peak after a game
engine import re-encode, so nothing clips on the way in.

## Did these work for you?

A rating takes about ten seconds and is the single most useful thing you can do
for a small pack like this - it is what decides whether anyone else ever finds
it.

https://moneywithjjcom.itch.io/free-explosion-sounds/rate

## Where the rest are

These 8 come from Explosions and Destruction SFX Library, which has 220 sounds in
total: https://moneywithjjcom.itch.io/explosions-destruction-library

Every themed pack in one purchase - 1007 sounds across
32 packs: https://moneywithjjcom.itch.io/complete-collection

There is also a wider free sampler drawing from 12 packs
at once: https://moneywithjjcom.itch.io/essentials-sampler

## Licence

Royalty-free for commercial and non-commercial work, including games and video
you sell. Unlimited projects, no attribution required, no expiry. Paid client
work is fine, and you may commit these files to a public source repository as
part of your project. You may not resell or redistribute the audio files on
their own, or include them in another sound library or pack.

## How these were made

Audio generated with ElevenLabs Sound Effects under a paid commercial
subscription, then screened, level-matched and edited by hand.
